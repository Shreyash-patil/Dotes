// /**
//  * Below are the colors that are used in the app. The colors are defined in the light and dark mode.
//  * There are many other ways to style your app. For example, [Nativewind](https://www.nativewind.dev/), [Tamagui](https://tamagui.dev/), [unistyles](https://reactnativeunistyles.vercel.app), etc.
//  */

// // const tintColorLight = '#0a7ea4';
// const tintColorLight = 'green';
// // const tintColorDark = '#fff';
// const tintColorDark = 'green';

// export const Colors = {
//   light: {
//     text: '#11181C',
//     background: '#fff',
//     headerBackgroundColor:'#484848',
//     tint: tintColorLight,
//     icon: '#687076',
//     tabIconDefault: '#687076',
//     tabIconSelected: tintColorLight,
//   },
//   dark: {
//     text: '#ECEDEE',
//     background: '#151718',
//     headerBackgroundColor:'#484848',
//     tint: tintColorDark,
//     icon: '#9BA1A6',
//     tabIconDefault: '#9BA1A6',
//     tabIconSelected: tintColorDark,
//   },
// };


/**
 * Below are the colors that are used in the app. The colors are defined in the light and dark mode.
 */

const tintColorLight = '#6200EE';
const tintColorDark = '#BB86FC';

export const Colors = {
  light: {
    text: '#11181C',
    background: '#fff',
    headerBackgroundColor: '#484848',
    tint: tintColorLight,
    icon: '#687076',
    tabIconDefault: '#687076',
    tabIconSelected: tintColorLight,
    // Additional theme values for our component:
    container: { backgroundColor: '#FAF9F6' },
    inputContainer: { backgroundColor: "white", borderColor: "#6200EE" },
    inputField: { backgroundColor: "white", color: "black" },
    addTodoButton: { color: "#6200EE" },
    addTodoButtonText: { color: "white" },
    flatListContainer: { backgroundColor: "#F5F5F5", borderColor: "#CADCFC" },
    todoTitle: { color: "black" },
    endOfListMsg: { color: "#555" },
    modalContent: { backgroundColor: "white" },
    modalTitle: { color: "black" },
    modalInput: { backgroundColor: "white", color: "black", borderColor: "#CCC" },
    modalButton: { backgroundColor: "#6200EE" },
    modalButtonText: { color: "white" },
    modalCancelButton: { backgroundColor: "#DDD" },
    modalCancelButtonText: { color: "black" },
  },
  dark: {
    text: '#ECEDEE',
    background: '#151718',
    headerBackgroundColor: '#484848',
    tint: tintColorDark,
    icon: '#9BA1A6',
    tabIconDefault: '#9BA1A6',
    tabIconSelected: tintColorDark,
    // Additional theme values for our component:
    container: { backgroundColor: "#121212" },
    inputContainer: { backgroundColor: "#1E1E1E", borderColor: "#BB86FC" },
    inputField: { backgroundColor: "#222", color: "white" },
    addTodoButton: { color: "#BB86FC" },
    addTodoButtonText: { color: "black" },
    flatListContainer: { backgroundColor: "#333", borderColor: "#5b6e8f" },
    todoTitle: { color: "white" },
    endOfListMsg: { color: "white" },
    modalOverlay: {
      flex: 1,backgroundColor: "rgba(0,0,0,0.5)",justifyContent: "center",alignItems: "center",},
    modalContent: { backgroundColor: "#1E1E1E" },
    modalTitle: { color: "white" },
    modalInput: { backgroundColor: "#222", color: "white", borderColor: "#444" },
    modalButton: { backgroundColor: "#BB86FC" },
    modalButtonText: { color: "black" },
    modalCancelButton: { backgroundColor: "#555" },
    modalCancelButtonText: { color: "white" },
  },
};
