// // This file is a fallback for using MaterialIcons on Android and web.

// import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { FontAwesome5 } from '@expo/vector-icons';
// import { SymbolWeight } from 'expo-symbols';
// import React from 'react';
// import { OpaqueColorValue, StyleProp, ViewStyle,TextStyle } from 'react-native';

// // Add your SFSymbol to MaterialIcons mappings here.
// const MAPPING = {
//   // See MaterialIcons here: https://icons.expo.fyi
//   // See SF Symbols in the SF Symbols app on Mac.
//   // 'house.fill': 'home',
//   // 'paperplane.fill': 'send',
//   // 'chevron.left.forwardslash.chevron.right': 'code',
//   // 'chevron.right': 'chevron-right',

//   'tasks':'tasks', // its from FontAwesome
//   'edit-note':'edit-note' // its from MaterialIcons
// } as Partial<
//   Record<
//     import('expo-symbols').SymbolViewProps['name'],
//     React.ComponentProps<typeof MaterialIcons>['name']
//   >
// >;

// export type IconSymbolName = keyof typeof MAPPING;

// /**
//  * An icon component that uses native SFSymbols on iOS, and MaterialIcons on Android and web. This ensures a consistent look across platforms, and optimal resource usage.
//  *
//  * Icon `name`s are based on SFSymbols and require manual mapping to MaterialIcons.
//  */
// export function IconSymbol({
//   name,
//   size = 24,
//   color,
//   style,
// }: {
//   name: IconSymbolName;
//   size?: number;
//   color: string | OpaqueColorValue;
//   style?: StyleProp<TextStyle>;
//   weight?: SymbolWeight;
// }) {
//   return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
// }


// import MaterialIcons from '@expo/vector-icons/MaterialIcons';
// import React from 'react';
// import { OpaqueColorValue, StyleProp, TextStyle } from 'react-native';

// // Define our own union type for allowed icon names
// export type IconSymbolName = 'tasks' | 'edit-note';

// // Create a mapping from our custom icon names to MaterialIcons names
// const MAPPING: Record<IconSymbolName, React.ComponentProps<typeof MaterialIcons>['name']> = {
//   tasks: 'tasks',
//   'edit-note': 'edit-note',
// };

// export function IconSymbol({
//   name,
//   size = 24,
//   color,
//   style,
// }: {
//   name: IconSymbolName;
//   size?: number;
//   color: string | OpaqueColorValue;
//   style?: StyleProp<TextStyle>;
// }) {
//   return (
//     <MaterialIcons
//       color={color}
//       size={size}
//       name={MAPPING[name]}
//       style={style}
//     />
    
//   );
// }



import React from 'react';
import { OpaqueColorValue, StyleProp, TextStyle } from 'react-native';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
// import { FontAwesome5 } from '@expo/vector-icons/FontAwesome5';

export type IconSymbolName = 'tasks' | 'edit-note';

export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
}) {
  if (name === 'tasks') {
    // Use FontAwesome5 for tasks
    return <FontAwesome5 name="tasks" size={size} color={color} style={style} />;
  } else if (name === 'edit-note') {
    // Use MaterialIcons for edit-note
    return <MaterialIcons name="edit-note" size={size} color={color} style={style} />;
  }
  return null;
}
