// import { useEffect } from 'react';
// import { View, StyleSheet } from 'react-native';
// import LottieView from 'lottie-react-native';
// import { useRouter } from 'expo-router';
// import * as SplashScreen from 'expo-splash-screen';

// export default function IndexSplashScreen() {
//   const router = useRouter();

//   useEffect(() => {
//     SplashScreen.preventAutoHideAsync();
//   }, []);

//   const handleAnimationFinish = () => {
//     SplashScreen.hideAsync();
//     router.replace('/(tabs)');
//   };

//   return (
//     <View style={styles.container}>
//       <LottieView
//         source={require('../assets/logoicons/Lottie-dotes-intro.json')}
//         autoPlay
//         loop={false}
//         onAnimationFinish={handleAnimationFinish}
//         style={styles.animation}
//       />
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#1C1C1C',
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   animation: {
//     width: 300,
//     height: 300,
//   },
// });

// import { useEffect } from 'react';
// import { View, StyleSheet, useColorScheme, Image } from 'react-native';
// import { useRouter } from 'expo-router';
// import * as SplashScreen from 'expo-splash-screen';

// export default function IndexSplashScreen() {
//   const router = useRouter();
//   const colorScheme = useColorScheme(); // Get the device theme
  
//   useEffect(() => {
//     SplashScreen.preventAutoHideAsync();
    
//     // Set a timeout to navigate after displaying the splash image
//     const timer = setTimeout(() => {
//       SplashScreen.hideAsync();
//       router.replace('/(tabs)');
//     }, 2000); // 2 seconds delay, adjust as needed
    
//     return () => clearTimeout(timer);
//   }, [router]);

//   return (
//     <View style={[
//       styles.container, 
//       { backgroundColor: colorScheme === 'dark' ? '#1C1C1C' : '#FFFFFF' }
//     ]}>
//       <Image
//         source={
//           colorScheme === 'dark' 
//             ? require('../assets/images/Dotes-dark-splash-trans-bg.png')
//             : require('../assets/images/Dotes-light-splash.png')
//         }
//         style={styles.image}
//         resizeMode="contain"
//       />
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   image: {
//     width: 350,
//     height: 350,
//   },
// });

import { useEffect, useState } from 'react';
import { View, StyleSheet, useColorScheme, Image, Animated } from 'react-native';
import { useRouter } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';

export default function IndexSplashScreen() {
  const router = useRouter();
  const colorScheme = useColorScheme(); // Get the device theme
  const fadeAnim = useState(new Animated.Value(0))[0]; // Initial opacity: 0
  
  useEffect(() => {
    SplashScreen.preventAutoHideAsync();
    
    // Fade in animation
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 1000, // 1 second fade in
      useNativeDriver: true,
    }).start();
    
    // Set a timeout for fade out and navigation
    const timer = setTimeout(() => {
      // Fade out animation
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 800, // 0.8 second fade out
        useNativeDriver: true,
      }).start(async () => {
        await SplashScreen.hideAsync();
        router.replace('/(tabs)');
      });
    }, 2300); // 2 seconds display time before fade out starts
    
    return () => clearTimeout(timer);
  }, [fadeAnim, router]);

  return (
    <View style={[
      styles.container, 
      { backgroundColor: colorScheme === 'dark' ? '#1C1C1C' : '#FFFFFF' }
    ]}>
      <Animated.View style={{ opacity: fadeAnim }}>
        <Image
          source={
            colorScheme === 'dark' 
            ? require('../assets/images/Dotes-dark-splash-trans-bg.png')
            : require('../assets/images/Dotes-light-splash.png')
          }
          style={styles.image}
          resizeMode="contain"
        />
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    width: 300,
    height: 300,
  },
});