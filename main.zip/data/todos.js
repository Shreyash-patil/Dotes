export const DATA = [
    {
        "id": 1,
        "title": "Finish reading the book",
        "completed": true
    },
    {
        "id": 2,
        "title": "Buy groceries",
        "completed": false
    },
    {
        "id": 3,
        "title": "Write a blog post",
        "completed": true
    },
    {
        "id": 4,
        "title": "Clean the house",
        "completed": false
    },
    {
        "id": 5,
        "title": "Work out",
        "completed": true
    },
    {
        "id": 6,
        "title": "Call the bank",
        "completed": false
    },
    {
        "id": 7,
        "title": "Fix the leaking faucet",
        "completed": true
    },
    {
        "id": 8,
        "title": "Plan the trip itinerary",
        "completed": false
    },
    {
        "id": 9,
        "title": "Attend the meeting",
        "completed": true
    },
    {
        "id": 10,
        "title": "Finish the project report",
        "completed": false
    },
    {
        "id": 11,
        "title": "Update the software",
        "completed": true
    },
    {
        "id": 12,
        "title": "Visit the doctor",
        "completed": false
    },
    {
        "id": 13,
        "title": "Organize the desk",
        "completed": true
    },
    {
        "id": 14,
        "title": "Cook dinner",
        "completed": false
    },
    {
        "id": 15,
        "title": "Reply to emails",
        "completed": true
    },
    {
        "id": 16,
        "title": "Finish the presentation",
        "completed": false
    },
    {
        "id": 17,
        "title": "Take the car for servicing",
        "completed": true
    },
    {
        "id": 18,
        "title": "Pay the bills",
        "completed": false
    },
    {
        "id": 19,
        "title": "Research for the article",
        "completed": true
    },
    {
        "id": 20,
        "title": "Set up the new computer",
        "completed": false
    }
]
