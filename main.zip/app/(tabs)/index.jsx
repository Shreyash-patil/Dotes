
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  Pressable,
  Modal,
  TextInput,
  StyleSheet,
  useColorScheme
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Colors } from '@/constants/Colors'; // Adjust this import based on your project structure
import LottieView from 'lottie-react-native';
import { Inter_500Medium, useFonts } from "@expo-google-fonts/inter";

export default function Notes() {
  const colorScheme = useColorScheme();
  const isDarkMode = colorScheme === "dark";
  const themeStyles = isDarkMode ? Colors.dark : Colors.light;

  // State for managing notes and modal
  const [notes, setNotes] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [currentNote, setCurrentNote] = useState({ id: null, title: '', body: '' });

  // Load notes from AsyncStorage when the component mounts
  useEffect(() => {
    const loadNotes = async () => {
      try {
        const storedNotes = await AsyncStorage.getItem('@notes');
        if (storedNotes !== null) {
          setNotes(JSON.parse(storedNotes));
        }
      } catch (e) {
        console.error('Failed to load notes', e);
      }
    };
    loadNotes();
  }, []);

  // Save notes to AsyncStorage whenever the notes array changes
  useEffect(() => {
    const saveNotes = async () => {
      try {
        await AsyncStorage.setItem('@notes', JSON.stringify(notes));
      } catch (e) {
        console.error('Failed to save notes', e);
      }
    };
      saveNotes();
  }, [notes]);

  // CRUD Functions
  const addOrUpdateNote = () => {
    if (currentNote.id) {
      // Update existing note
      setNotes(notes.map(note => (note.id === currentNote.id ? currentNote : note)));
    } else {
      // Add new note
      const newId = notes.length > 0 ? Math.max(...notes.map(note => note.id)) + 1 : 1;
      setNotes([...notes, { ...currentNote, id: newId }]);
    }
    setModalVisible(false);
    setCurrentNote({ id: null, title: '', body: '' }); // Reset form
  };

  const deleteNote = (id) => {
    setNotes(notes.filter(note => note.id !== id));
  };

  const openNoteModal = (note = { id: null, title: '', body: '' }) => {
    setCurrentNote(note);
    setModalVisible(true);
  };

  // Render individual note card
  const renderNote = ({ item }) => (
    <View style={[styles.noteCard, themeStyles.flatListContainer]}>
      <Pressable onPress={() => openNoteModal(item)}>

      <View style={[styles.accent, { // Top-left horizontal
    top: -15,
    left: -15,
    width: 40,
    height: 2,
    backgroundColor: '#6200EE',
    
    borderTopLeftRadius: 8,
    borderTopLeftRadius: 8,
    borderTopRightRadius: 8,
    borderBottomRightRadius: 8,
  }]} />
    <View style={[styles.accent, { // Top-left vertical
    top: -15,
    left: -15.1,
    width: 2,
    height: 40,
    backgroundColor: '#6200EE',
    borderTopLeftRadius: 8,
    borderBottomRightRadius: 8,
    borderBottomLeftRadius: 8,
  }]} />
        <Text style={[styles.noteTitle, themeStyles.todoTitle]}>{item.title}</Text>
        <Text style={[styles.noteBody, themeStyles.todoTitle]} numberOfLines={4}>{item.body}</Text>
        <View style={styles.noteActions}>

           {/* Bottom‑right horizontal */}
  <View style={[styles.accent, {
    bottom: -16,
    right: -15,
    width: 40,
    height: 2,
    backgroundColor: '#6200EE',
    borderBottomRightRadius: 8,
    borderBottomLeftRadius: 8,
    borderTopLeftRadius: 8,
  }]} />

  {/* Bottom‑right vertical */}
  <View style={[styles.accent, {
    bottom: -16,
    right: -15.5,
    width: 2,
    height: 40,
    backgroundColor: '#6200EE',
    borderBottomRightRadius: 8,
    borderTopRightRadius: 8,
    borderTopLeftRadius: 8,
  }]} />
          <Pressable onPress={() => deleteNote(item.id)}>
            <MaterialIcons name="delete-outline" size={24} color="#EF4040" />
          </Pressable>
        </View>
      </Pressable>
    </View>
  );

  return (
    <SafeAreaView style={[styles.container, themeStyles.container]}>
      {/* Notes List */}
      <FlatList
        data={notes}
        renderItem={renderNote}
        keyExtractor={item => item.id.toString()}
        ListEmptyComponent={<Text style={[styles.emptyText, themeStyles.endOfListMsg]}>No notes yet. Add one!</Text>}

      />


      {/* Add Note Button (Bottom-Right Corner) */}
      <Pressable style={styles.addButton} onPress={() => openNoteModal()}>
        <LottieView
          source={require('../../assets/animations/Note-plus-animation.json')}
          autoPlay
          loop
          style={{ width: 70, height: 70 }}
        />
      </Pressable>

      {/* Modal for Adding/Editing Notes */}
      <Modal visible={modalVisible} animationType="slide">
        <View style={[styles.modalContent, themeStyles.modalContent]}>
          <Text style={[styles.modalTitle, themeStyles.modalTitle]}>
            {currentNote.id ? 'Edit Note' : 'Add Note'}
          </Text>
          <TextInput
            style={[styles.input, themeStyles.modalInput]}
            placeholder="Title"
            placeholderTextColor="#aaa"
            value={currentNote.title}
            clearButtonMode="always"
            onChangeText={text => setCurrentNote({ ...currentNote, title: text })}
          />
          <TextInput
            style={[styles.input, { height: 100 }, themeStyles.modalInput]}
            placeholder="Body"
            placeholderTextColor="#aaa"
            value={currentNote.body}
            onChangeText={text => setCurrentNote({ ...currentNote, body: text })}
            multiline
          />
          <View style={[styles.modalActions, themeStyles.modalContent]}>
            <Pressable style={[styles.modalButton, themeStyles.modalButton]} onPress={addOrUpdateNote}>
              <Text style={[styles.modalButtonText, themeStyles.modalButtonText]}>Save</Text>
            </Pressable>
            <Pressable
              style={[styles.modalCancelButton, themeStyles.modalCancelButton]}
              onPress={() => setModalVisible(false)}
            >
              <Text style={[styles.modalCancelButtonText, themeStyles.modalCancelButtonText]}>Cancel</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

// Styles aligned with your app's theme
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 5,
    paddingTop: 17,
  },
  noteCard: {
    position: 'relative',
    padding: 15,
    borderRadius: 10,
    borderTopLeftRadius: 0,
    borderBottomRightRadius: 0,
    // borderStartColor: '#6200EE',
    marginBottom: 7,
    marginTop: 8,
    marginHorizontal: 10,
    // Optional border for definition
 
    // Shadow properties for iOS
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    // Shadow property for Android
    elevation: 8,

    // padding: 15,                // Internal spacing for content
    // borderRadius: 10,          // Rounded corners for a modern look
    // marginBottom: 10, 
    // marginHorizontal:10,         // Space between notes in the list
    // // borderWidth: 2,            // Thickness of the border
    // // borderColor: '#6200EE', // Colored border using the app's accent color

    // shadowColor: '#6200EE', // Shadow color matches the border for cohesion
    // shadowOffset: { width: 0, height: 0 }, // Shadow centered around the note
    // shadowOpacity: 0.5,        // Shadow visibility (0 to 1)
    // shadowRadius: 6,           // How spread out the shadow is
    // elevation: 5,
  },

  accent: {
    position: 'absolute',
    shadowColor: '#6200EE',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 8,
    // Shadow property for Android
    elevation: 8,
  },
  noteTitle: {
    fontFamily: "Inter_500Medium", // Bold sans-serif (replace with your font if available)
    fontWeight: 'bold',
    fontSize: 24,
    color: '#fff',
  },
  noteBody: {
    fontFamily: "Inter_500Medium", // Regular sans-serif
    fontSize: 14,
    color: '#ddd',
    marginTop: 5,
  },
  noteActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 10,
    gap: 15,
  },
  addButton: {
    position: 'absolute',
    bottom: 70,
    right: 6,
    padding: 15,
  },
  modalContent: {
    flex: 1,
    padding: 20,
    backgroundColor: '#1c2526', // Consistent with main background
  },
  modalTitle: {
    fontFamily: "Inter_500Medium",
    fontWeight: 'bold',
    fontSize: 24,
    color: '#fff',
    marginBottom: 20,
  },
  input: {
    padding: 10,
    borderWidth: 1,
    borderRadius: 5,
    borderColor: '#fff',
    fontSize: 18,
    marginBottom: 20,
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  modalButton: {
    padding: 10,
    borderRadius: 5,
    width: "40%",
    alignItems: "center",
  },
  modalButtonText: {
    fontSize: 16,
    fontWeight: "bold",
  },
  modalCancelButton: {
    padding: 10,
    borderRadius: 5,
    width: "40%",
    alignItems: "center",
  },
  modalCancelButtonText: {
    fontSize: 16,
    fontWeight: "bold",
  },
  emptyText: {
    color: '#fff',
    textAlign: 'center',
    marginTop: 20,
    fontFamily: "Inter_500Medium",
  },
});