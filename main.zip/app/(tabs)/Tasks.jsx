import {
  Text,
  View,
  TextInput,
  Pressable,
  StyleSheet,
  FlatList,
  useColorScheme,
  Modal,
  Animated,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useState, useEffect, useRef } from "react";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { Inter_500Medium, useFonts } from "@expo-google-fonts/inter";
import { Colors } from "@/constants/Colors";
import AsyncStorage from "@react-native-async-storage/async-storage";
import LottieView from "lottie-react-native";
import { CheckCircle } from "react-native-feather";

export default function Tasks() {
  const colorScheme = useColorScheme();
  const isDarkMode = colorScheme === "dark";
  const themeStyles = isDarkMode ? Colors.dark : Colors.light;
  const [modalVisible, setModalVisible] = useState(false);
  const [editingTodo, setEditingTodo] = useState(null);
  const [editedText, setEditedText] = useState("");
  const [todos, setTodos] = useState([]);
  const [text, setText] = useState("");
  const [isTodoAdded, setIsTodoAdded] = useState(false);
  const [fontLoaded] = useFonts({ Inter_500Medium });

  const checkBoxAnimationStyle = isDarkMode
    ? require("../../assets/animations/complete-todo-dark.json")
    : require("../../assets/animations/complete-todo-light.json");

  const [checkBoxProgress, setCheckBoxProgress] = useState({});

  useEffect(() => {
    const loadTodos = async () => {
      try {
        const storedTodos = await AsyncStorage.getItem("@todos");
        if (storedTodos !== null) {
          const parsedTodos = JSON.parse(storedTodos);
          const sortedTodos = parsedTodos.sort((a, b) => b.id - a.id);
          setTodos(sortedTodos);
          const initialProgress = {};
          sortedTodos.forEach((todo) => {
            initialProgress[todo.id] = todo.completed ? 1 : 0;
          });
          setCheckBoxProgress(initialProgress);
        }
      } catch (e) {
        console.error("Failed to load todos", e);
      }
    };

    loadTodos();
  }, []);

  useEffect(() => {
    const saveTodos = async () => {
      try {
        await AsyncStorage.setItem("@todos", JSON.stringify(todos));
      } catch (e) {
        console.error("Failed to save todos", e);
      }
    };

    saveTodos();
  }, [todos]);

  const addTodo = () => {
    if (text.trim()) {
      const newId =
        todos.length > 0 ? Math.max(...todos.map((todo) => todo.id)) + 1 : 1;
      const newTodo = { id: newId, title: text, completed: false };
      setTodos([newTodo, ...todos]);
      setCheckBoxProgress((prev) => ({ ...prev, [newId]: 0 }));
      setText("");
      setIsTodoAdded(true);

      setTimeout(() => setIsTodoAdded(false), 1500);
    }
  };

  const updateTodo = () => {
    setTodos(
      todos.map((todo) =>
        todo.id === editingTodo.id ? { ...todo, title: editedText } : todo
      )
    );
    setModalVisible(false);
    setEditingTodo(null);
  };

  const toggleTodo = (id) => {
    const todo = todos.find((todo) => todo.id === id);
    if (todo) {
      setEditingTodo(todo);
      setEditedText(todo.title);
      setModalVisible(true);
    }
  };

  const removeTodo = (id) => {
    setTodos(todos.filter((todo) => todo.id !== id));
    setCheckBoxProgress((prev) => {
      const newProgress = { ...prev };
      delete newProgress[id];
      return newProgress;
    });
  };

  const animatedValues = useRef({});
  const textWidths = useRef({});
  const textLines = useRef({});

  const getAnimatedValue = (id) => {
    if (!animatedValues.current[id]) {
      animatedValues.current[id] = new Animated.Value(0);
    }
    return animatedValues.current[id];
  };

  const toggleCompleted = (id) => {
    setTodos(
      todos.map((todo) => {
        if (todo.id === id) {
          const newCompleted = !todo.completed;
          animateLine(id, newCompleted);
          animateCheckBox(id, newCompleted);
          return { ...todo, completed: newCompleted };
        }
        return todo;
      })
    );
  };

  const animateLine = (id, completed) => {
    Animated.timing(getAnimatedValue(id), {
      toValue: completed ? 1 : 0,
      duration: 500,
      useNativeDriver: false,
    }).start();
  };

  const animateCheckBox = (id, completed) => {
    const animValue = new Animated.Value(completed ? 0 : 1);
    Animated.timing(animValue, {
      toValue: completed ? 1 : 0,
      duration: 500,
      useNativeDriver: false,
    }).start();

    animValue.addListener(({ value }) => {
      setCheckBoxProgress((prev) => ({ ...prev, [id]: value }));
    });
  };

  const renderList = ({ item }) => {
    const animation = getAnimatedValue(item.id);
    const lineWidth = animation.interpolate({
      inputRange: [0, 1],
      outputRange: [0, textWidths.current[item.id] || 0],
    });

    const progress =
      checkBoxProgress[item.id] !== undefined
        ? checkBoxProgress[item.id]
        : item.completed
        ? 1
        : 0;

    return (
      <View style={[styles.flatListContainer, themeStyles.flatListContainer]}>
        <View style={styles.checkboxContainer}>
          <Pressable
            onPress={() => toggleCompleted(item.id)}
            style={styles.completeButton}
          >
            {!item.completed && progress === 0 ? (
              <MaterialIcons
                name="radio-button-unchecked"
                size={25}
                color="#BB86FC"
              />
            ) : (
              <LottieView
                source={checkBoxAnimationStyle}
                progress={progress}
                style={styles.checkboxAnimation}
              />
            )}
          </Pressable>
        </View>

        <Pressable
          onPress={() => toggleTodo(item.id)}
          style={styles.todoTextView}
        >
          <View style={styles.textContainer}>
            <Text
              style={[
                styles.todoTitle,
                themeStyles.todoTitle,
                item.completed && styles.completedTodoText,
              ]}
              numberOfLines={4}
              ellipsizeMode="tail"
              onTextLayout={(e) => {
                textLines.current[item.id] = e.nativeEvent.lines;
              }}
            >
              {item.title}
            </Text>

            {textLines.current[item.id]?.map((line, index) => {
              const lineWidth = animation.interpolate({
                inputRange: [0, 1],
                outputRange: [0, line.width],
              });

              return (
                <Animated.View
                  key={index}
                  style={[
                    styles.animatedLine,
                    {
                      width: lineWidth,
                      top: line.y + line.height / 2,
                      left: line.x,
                      backgroundColor: themeStyles.tint,
                    },
                  ]}
                />
              );
            })}
          </View>
        </Pressable>

        <View style={styles.todoDeleteButtonView}>
          <Pressable onPress={() => removeTodo(item.id)}>
            <MaterialIcons name="delete-outline" size={24} color="#EF4040" />
          </Pressable>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={[styles.container, themeStyles.container]}>
      <View style={[styles.inputContainer, themeStyles.inputContainer]}>
        <TextInput
          style={[styles.inputField, themeStyles.inputField]}
          placeholder="Add a new Task"
          placeholderTextColor="gray"
          value={text}
          onChangeText={setText}
          multiline={true}
          numberOfLines={4}
          maxLength={100}
          clearButtonMode="always"
        />
        <Pressable onPress={addTodo}>
          {isTodoAdded ? (
            <LottieView
              source={require("../../assets/animations/AddTodo-animation.json")}
              autoPlay
              loop={false}
              style={[styles.animation, themeStyles.addTodoButton]}
            />
          ) : (
            <LottieView
              source={require("../../assets/animations/AddTodo-animation.json")}
              loop={false}
              progress={0.8}
              style={[styles.animation, themeStyles.addTodoButton]}
            />
          )}
        </Pressable>
      </View>

      <View style={styles.divider}></View>

      <FlatList
        data={todos}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderList}
        ListEmptyComponent={
          <Text style={[styles.NoTaskMsg, themeStyles.endOfListMsg]}>
            No tasks yet. Add one!
          </Text>
        }
      />

      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, themeStyles.modalContent]}>
            <Text style={[styles.modalTitle, themeStyles.modalTitle]}>
              Edit Task
            </Text>
            <TextInput
              style={[styles.modalInput, themeStyles.modalInput]}
              value={editedText}
              numberOfLines={10}
              multiline
              onChangeText={setEditedText}
              placeholder="Update task..."
              placeholderTextColor={isDarkMode ? "#AAA" : "gray"}
            />
            <View style={styles.modalButtonContainer}>
              <Pressable
                style={[styles.modalButton, themeStyles.modalButton]}
                onPress={updateTodo}
              >
                <Text
                  style={[styles.modalButtonText, themeStyles.modalButtonText]}
                >
                  Update
                </Text>
              </Pressable>
              <Pressable
                style={[
                  styles.modalCancelButton,
                  themeStyles.modalCancelButton,
                ]}
                onPress={() => setModalVisible(false)}
              >
                <Text
                  style={[
                    styles.modalCancelButtonText,
                    themeStyles.modalCancelButtonText,
                  ]}
                >
                  Cancel
                </Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: "black",
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 10,
    marginBottom: 10,
    paddingHorizontal: 10,
    paddingVertical: 8,
    width: "100%",
    maxWidth: 400,
    backgroundColor: "#333",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#CADCFC",
    justifyContent: "space-evenly"
  },
  inputField: {
    flex: 1,
    height: 40,
    borderRadius: 8,
    paddingHorizontal: 1,
    maxWidth: 280,
    fontSize: 16,
    color: "white",
    backgroundColor: "#222",
    fontFamily: "Inter_500Medium",
    marginRight: 19,
  },
  addTodoButton: {
    backgroundColor: "#00246B",
    borderWidth: 3,
    borderColor: "#CADCFC",
    borderRadius: 5,
    paddingHorizontal: 15,
    paddingVertical: 8,
    height: 40,
    width: 80,
  },
  animation: {
    width: 31,
    height: 31,
    padding: 0,
    position: "absolute",
    top: -15,
    left: -27,
  },
  addTodoButtonText: {
    fontSize: 16,
    fontWeight: "bold",
    color: "white",
    fontFamily: "Inter_500Medium",
  },
  divider: {
    borderBottomColor: "gray",
    borderBottomWidth: StyleSheet.hairlineWidth,
    margin: 5,
  },
  flatListContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 10,
    marginBottom: 4,
    padding: 10,
    width: "100%",
    backgroundColor: "#333",
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#CADCFC",
  },
  checkboxContainer: {
    width: 30, // Fixed width to prevent layout shift
    height: 30, // Fixed height to match
    justifyContent: "center",
    alignItems: "center",
    marginRight: 10,
  },
  completeButton: {
    justifyContent: "center",
    alignItems: "center",
  },
  checkboxAnimation: {
    width: 55, // Slightly larger to match visual size
    height: 55,
  },
  todoTextView: {
    width: "50%",
    paddingLeft: 3,
    flexGrow: 1,
  },
  textContainer: {
    position: "relative",
  },
  todoTitle: {
    color: "white",
    fontSize: 15,
    fontFamily: "Inter_500Medium",
  },
  animatedLine: {
    position: "absolute",
    height: 2,
    borderRadius: 1,
  },
  completedTodoText: {
    color: "gray",
    fontFamily: "Inter_500Medium",
  },
  todoDeleteButtonView: {
    marginLeft: 10,
  },
  NoTaskMsg: {
    color: "#fff",
    textAlign: "center",
    marginTop: 20,
    fontFamily: "Inter_500Medium",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContent: {
    width: "80%",
    backgroundColor: "white",
    borderRadius: 10,
    padding: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 10,
    textAlign: "center",
  },
  modalInput: {
    padding: 10,
    borderWidth: 1,
    borderRadius: 5,
    fontSize: 18,
    marginBottom: 20,
  },
  modalButtonContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
  modalButton: {
    padding: 10,
    borderRadius: 5,
    width: "40%",
    alignItems: "center",
  },
  modalButtonText: {
    fontSize: 16,
    fontWeight: "bold",
  },
  modalCancelButton: {
    padding: 10,
    borderRadius: 5,
    width: "40%",
    alignItems: "center",
  },
  modalCancelButtonText: {
    fontSize: 16,
    fontWeight: "bold",
  },
});
